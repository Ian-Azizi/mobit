package com.example.demo.repository;

import com.example.demo.entites.Product;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends CrudRepository<Product,Long> {
    List<Product>findAllById(long id);
    List<Product>findAllByTitle(String title);

}
