package com.example.demo.controller.api;


import com.example.demo.Service.ProductService;
import com.example.demo.entites.Product;
import com.example.demo.helper.ui.ServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import  com.example.demo.helper.ui.ResponseStatus;
import java.util.List;

@RestController
//@RequestMapping("/api/Product")
public class ProductController {
    @Autowired
    private ProductService service;
    @RequestMapping(value = "/test/Product", produces = "application/json")
    public ServiceResponse<Product> getId(long id){
        try{
            List<Product> get = service.getById(id);
            return  new ServiceResponse<Product>(ResponseStatus.SUCCESS,get);
        }catch (Exception e){
            return new ServiceResponse<Product>(e);
        }
    }
    @RequestMapping(value = "/Product/Title", produces = "application/json")
    public ServiceResponse<Product>getCompany_Name(String title){
        return new ServiceResponse<Product>(ResponseStatus.SUCCESS,new Product());
    }
    @RequestMapping("/Product/post")
    public ServiceResponse<Product>addProduct(@RequestBody Product Date){
        try{
            List<Product> adding = service.add(Date);
            return new ServiceResponse<Product>(ResponseStatus.SUCCESS,adding);
        }catch (Exception e){
            return new ServiceResponse<Product>(e);
        }
//        return new ServiceResponse<Product>(ResponseStatus.SUCCESS, Date);
    }
    @PutMapping("/Product/put")
    public ServiceResponse<Product>upDateProduct(@RequestBody Product data){

        Product updateData = service.upData(data);
        return new ServiceResponse<Product>(ResponseStatus.SUCCESS,updateData);

//        return new ServiceResponse<Product>(ResponseStatus.SUCCESS,data);
    }
    @DeleteMapping("/project/{id}")
    public ServiceResponse<Boolean> delete(@PathVariable long id) {
        try {
            boolean result = service.deleteById(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
    @GetMapping("/Product")
    public Product test(){
        return new Product();
    }
}
