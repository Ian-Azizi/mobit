package com.example.demo.helper.Expection;

public class DataNotFoundException extends RuntimeException {
    public DataNotFoundException (String message){
        super(message);
    }
}
