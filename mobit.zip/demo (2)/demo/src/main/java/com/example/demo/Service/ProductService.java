package com.example.demo.Service;

import com.example.demo.entites.Product;
import com.example.demo.helper.Expection.DataNotFoundException;
import com.example.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository repository;

    public List<Product>getById(long id){
        List<Product>list = new ArrayList<>();
        return repository.findAllById(id);
    }
    public List<Product>getByTitle(String title){
        List<Product>list = new ArrayList<>();
        return repository.findAllByTitle(title);
    }
    public List<Product>add(Product data){
        return Collections.singletonList(repository.save(data));
    }
    public Product upData(Product data)  {
       Product oldDate = (Product) getById(data.getId());

       oldDate.setTitle(data.getTitle());
       oldDate.setColor(data.getColor());
       oldDate.setDescription(data.getDescription());
       oldDate.setLink(data.getLink());
       oldDate.setImage(data.getImage());
       oldDate.setPrice(data.getPrice());

        return repository.save(data);

    }
    public boolean deleteById(long id){
    Product oldDate = (Product) getById(id);
    if (oldDate==null){
        throw new DataNotFoundException("data with id"+id+"not found");
    }
    repository.deleteById(id);
    return true;
    }
}
    

